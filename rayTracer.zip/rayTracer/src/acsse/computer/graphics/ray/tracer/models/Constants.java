package acsse.computer.graphics.ray.tracer.models;

public class Constants {
	public final static float T_MIN = 0.0001f;
	public final static float T_MAX = 1.0e30f;
}
