package acsse.computer.graphics.ray.tracer.objects;

public class Triangle {
}
