package acsse.computer.graphics.ray.tracer.models;

public enum LIGHT_TYPE {
    DIRECTIONAL,
    AMBIENT,
    POINT
}
